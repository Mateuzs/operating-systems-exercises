//
//  main3.h
//  lab3
//
//  Created by Mateusz Zembol on 23.03.2018.
//  Copyright © 2018 Mateusz Zembol. All rights reserved.
//

#ifndef main3_h
#define main3_h

#include <stdio.h>

#endif /* main3_h */
