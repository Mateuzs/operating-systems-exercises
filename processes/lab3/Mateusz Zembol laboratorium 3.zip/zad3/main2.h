//
//  main2.h
//  lab3
//
//  Created by Mateusz Zembol on 23.03.2018.
//  Copyright © 2018 Mateusz Zembol. All rights reserved.
//

#ifndef main2_h
#define main2_h

#include <stdio.h>

#endif /* main2_h */
