//
//  zad1.h
//  lab2
//
//  Created by Mateusz Zembol on 16.03.2018.
//  Copyright © 2018 Mateusz Zembol. All rights reserved.
//

#ifndef zad1_h
#define zad1_h

#include <stdio.h>

void generate();
#endif /* zad1_h */
