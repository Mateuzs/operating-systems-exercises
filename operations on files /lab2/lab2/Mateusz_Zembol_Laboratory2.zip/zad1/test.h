//
//  test.h
//  lab2
//
//  Created by Mateusz Zembol on 16.03.2018.
//  Copyright © 2018 Mateusz Zembol. All rights reserved.
//

#ifndef test_h
#define test_h

#include <stdio.h>

#endif /* test_h */
