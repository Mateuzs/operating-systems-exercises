//
//  sort.h
//  lab2
//
//  Created by Mateusz Zembol on 16.03.2018.
//  Copyright © 2018 Mateusz Zembol. All rights reserved.
//

#ifndef sort_h
#define sort_h

#include <stdio.h>


void sort();
void sort_sys();

#endif /* sort_h */
