//
//  copy.h
//  lab2
//
//  Created by Mateusz Zembol on 16.03.2018.
//  Copyright © 2018 Mateusz Zembol. All rights reserved.
//

#ifndef copy_h
#define copy_h

#include <stdio.h>

 void copy();
 void copy_sys();


#endif /* copy_h */
