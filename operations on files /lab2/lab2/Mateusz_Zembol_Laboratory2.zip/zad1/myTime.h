//
//  time.h
//  lab2
//
//  Created by Mateusz Zembol on 16.03.2018.
//  Copyright © 2018 Mateusz Zembol. All rights reserved.
//

#ifndef myTime_h
#define myTime_h

#include <stdio.h>

void showTime();
void setTime();
void countTime();

#endif /* time_h */
