//
//  nftw.h
//  lab2
//
//  Created by Mateusz Zembol on 14.03.2018.
//  Copyright © 2018 Mateusz Zembol. All rights reserved.
//

#ifndef nftw_h
#define nftw_h

#include <stdio.h>

#endif /* nftw_h */
