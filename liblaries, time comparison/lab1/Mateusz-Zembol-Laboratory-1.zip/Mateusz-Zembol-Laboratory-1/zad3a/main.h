//
//  main.h
//  lab1
//
//  Created by Mateusz Zembol on 07.03.2018.
//  Copyright © 2018 Mateusz Zembol. All rights reserved.
//

#ifndef main_h
#define main_h

#include <stdio.h>

#endif /* main_h */
