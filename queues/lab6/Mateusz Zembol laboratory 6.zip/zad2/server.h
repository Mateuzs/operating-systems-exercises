//
//  server.h
//  lab6
//
//  Created by Mateusz Zembol on 22.04.2018.
//  Copyright © 2018 Mateusz Zembol. All rights reserved.
//

#ifndef server_h
#define server_h

#include <stdio.h>

#endif /* server_h */
