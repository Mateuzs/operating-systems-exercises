//
//  client.h
//  lab6
//
//  Created by Mateusz Zembol on 22.04.2018.
//  Copyright © 2018 Mateusz Zembol. All rights reserved.
//

#ifndef client_h
#define client_h

#include <stdio.h>

#endif /* client_h */
