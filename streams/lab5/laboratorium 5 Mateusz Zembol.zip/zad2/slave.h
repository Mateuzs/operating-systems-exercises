//
//  slave.h
//  lab5
//
//  Created by Mateusz Zembol on 15.04.2018.
//  Copyright © 2018 Mateusz Zembol. All rights reserved.
//

#ifndef slave_h
#define slave_h

#include <stdio.h>

#endif /* slave_h */
