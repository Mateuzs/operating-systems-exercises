//
//  main.h
//  lab5
//
//  Created by Mateusz Zembol on 13.04.2018.
//  Copyright © 2018 Mateusz Zembol. All rights reserved.
//

#ifndef main_h
#define main_h

#include <stdio.h>

#endif /* main_h */
